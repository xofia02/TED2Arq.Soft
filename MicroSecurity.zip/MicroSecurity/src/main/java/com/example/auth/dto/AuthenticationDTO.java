package com.example.auth.dto;

public record AuthenticationDTO(String login, String password) {
}
