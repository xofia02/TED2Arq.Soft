package com.example.Laboratorio_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratorioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
