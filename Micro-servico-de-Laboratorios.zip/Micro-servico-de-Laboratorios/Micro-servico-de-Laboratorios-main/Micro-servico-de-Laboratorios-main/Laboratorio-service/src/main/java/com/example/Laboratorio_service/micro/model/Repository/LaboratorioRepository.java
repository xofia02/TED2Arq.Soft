package com.example.Laboratorio_service.micro.model.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Laboratorio_service.micro.model.entity.Laboratorio;

public interface LaboratorioRepository extends JpaRepository<Laboratorio, Long>{

}
