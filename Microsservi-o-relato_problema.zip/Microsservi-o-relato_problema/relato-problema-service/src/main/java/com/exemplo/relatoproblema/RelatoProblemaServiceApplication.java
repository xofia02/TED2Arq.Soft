package com.exemplo.relatoproblema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelatoProblemaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelatoProblemaServiceApplication.class, args);
	}

}
