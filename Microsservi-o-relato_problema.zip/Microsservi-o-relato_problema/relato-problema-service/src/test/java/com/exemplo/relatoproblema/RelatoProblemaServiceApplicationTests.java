package com.exemplo.relatoproblema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelatoProblemaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
