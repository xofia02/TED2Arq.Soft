package com.example.solicitacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolicitacaoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
