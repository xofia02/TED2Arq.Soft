package com.example.solicitacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolicitacaoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolicitacaoServiceApplication.class, args);
	}

}
