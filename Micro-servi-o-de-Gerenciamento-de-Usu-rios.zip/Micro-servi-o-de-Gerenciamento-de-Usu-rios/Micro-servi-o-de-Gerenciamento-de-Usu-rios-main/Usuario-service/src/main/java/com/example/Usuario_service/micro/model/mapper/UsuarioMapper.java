package com.example.Usuario_service.micro.model.mapper;

import com.example.Usuario_service.micro.dto.*;
import com.example.Usuario_service.micro.model.entity.*;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface UsuarioMapper {
	
	 UsuarioMapper INSTANCE = Mappers.getMapper(UsuarioMapper.class);

	    UsuarioDTO toDto(Usuario usuario);
	    Usuario toEntity(UsuarioDTO dto);
}
