package com.example.Usuario_service.micro.dto;
import com.example.Usuario_service.micro.model.entity.*;

public class UsuarioDTO {
    private Long id;
    private String nome;
    private String email;
    private String senhaHash;
    private TipoUsuario tipo; // Usando o enum TipoUsuario
    
    // Getters e Setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenhaHash() {
		return senhaHash;
	}
	public void setSenhaHash(String senhaHash) {
		this.senhaHash = senhaHash;
	}
	public TipoUsuario getTipo() {
		return tipo;
	}
	public void setTipo(TipoUsuario tipo) {
		this.tipo = tipo;
	}
    
}