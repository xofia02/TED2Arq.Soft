package com.example.Usuario_service.micro.model.entity;

public enum TipoUsuario {
PROFESSOR,
ADMIN
}
