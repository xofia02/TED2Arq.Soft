package com.example.Usuario_service.micro.model.repository;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Usuario_service.micro.model.entity.*;

@Mapper(componentModel = "spring")
public interface UsuarioRepository extends JpaRepository<Usuario, Long>{

	List<Usuario> findByTipo(TipoUsuario tipo);

}
